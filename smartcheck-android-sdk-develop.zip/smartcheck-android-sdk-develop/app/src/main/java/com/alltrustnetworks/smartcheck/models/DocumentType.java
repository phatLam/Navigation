package com.alltrustnetworks.smartcheck.models;

public class DocumentType {
    public static int CHECK = 0;
    public static int DOC_ID = 1;
}
