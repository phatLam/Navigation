package com.alltrustnetworks.smartcheck.models.consumer;

public class PhoneConfirm {
    private String cell_phone;

    public PhoneConfirm(String cell_phone) {
        this.cell_phone = cell_phone;
    }

    public String getCell_phone() {
        return cell_phone;
    }

    public void setCell_phone(String cell_phone) {
        this.cell_phone = cell_phone;
    }
}
