package com.alltrustnetworks.smartcheck.models;

public class MakerStatus {
    public static final String GOOD = "good";
    public static final String NEUTRAL = "neutral";
}
