package com.example.shopbacktest.base.fragment

import android.support.v4.app.Fragment
import com.example.shopbacktest.di.Injectable
import com.example.shopbacktest.di.ViewModelFactory
import javax.inject.Inject

class BaseFragment: Fragment(), Injectable{
    @Inject
    lateinit var viewModelFactory: ViewModelFactory


}