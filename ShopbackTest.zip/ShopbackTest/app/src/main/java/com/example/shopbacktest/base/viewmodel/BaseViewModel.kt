package com.example.shopbacktest.base.viewmodel

import android.arch.lifecycle.ViewModel
import android.util.Log
import io.reactivex.disposables.Disposable

open class BaseViewModel(): ViewModel() {
    open val disposable = mutableListOf<Disposable>()
    override fun onCleared() {
        disposable.filter { !it.isDisposed }.forEach { it.dispose() }
        disposable.clear()
        super.onCleared()
    }
}