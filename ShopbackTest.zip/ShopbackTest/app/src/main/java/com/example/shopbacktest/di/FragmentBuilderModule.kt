package com.example.shopbacktest.di

import dagger.Module

@Suppress("unused")
@Module
abstract class FragmentBuilderModule {
}