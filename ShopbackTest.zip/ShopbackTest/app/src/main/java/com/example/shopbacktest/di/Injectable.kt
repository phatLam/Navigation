package com.example.shopbacktest.di


//Marks an activity / fragment injectable.
interface Injectable {
}