package com.example.shopbacktest.ui.Users

import android.arch.lifecycle.ViewModel

class UsersViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
