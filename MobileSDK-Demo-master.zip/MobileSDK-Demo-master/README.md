SmartCheck Demo app
===

In order to run the project please make sure gradle >= 4.4 is installed.

More info about how to run it from Android Studio can be found here:

[https://developer.android.com/training/basics/firstapp/running-app](https://developer.android.com/training/basics/firstapp/running-app)
